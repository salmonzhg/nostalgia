package com.salmonzhg.nostalgia.processor;

import com.google.auto.common.BasicAnnotationProcessor;
import com.google.auto.service.AutoService;
import com.google.common.collect.ImmutableSet;
import com.nostalgia.step.ReceiveStep;

import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.SourceVersion;

/**
 * author: Salmon
 * date: 2017-06-14 23:28
 * github: https://github.com/billy96322
 * email: salmonzhg@foxmail.com
 */

@AutoService(Processor.class)
public class NostalgiaProcessor extends BasicAnnotationProcessor {
    @Override
    protected Iterable<? extends ProcessingStep> initSteps() {
        return ImmutableSet.of(
                new ReceiveStep()
        );
    }

    @Override
    protected void postRound(RoundEnvironment roundEnv) {
        System.out.println("asd | postRound");
        super.postRound(roundEnv);
    }

    @Override
    public SourceVersion getSupportedSourceVersion() {
        return SourceVersion.latestSupported();
    }
}
