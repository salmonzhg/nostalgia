package com.salmonzhg.nostalgia.processor;

/**
 * author: Salmon
 * date: 2017-06-27 14:40
 * github: https://github.com/billy96322
 * email: salmonzhg@foxmail.com
 */

public class CodeGenerator {


}
